package security.test;

/**
 * Classe utilitária de teste UserRole
 * @generated
 **/
public class UserRoleTest {
	
}
