package security.test;

/**
 * Classe utilitária de teste User
 * @generated
 **/
public class UserTest {
	
}
