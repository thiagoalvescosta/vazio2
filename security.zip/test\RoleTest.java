package security.test;

/**
 * Classe utilitária de teste Role
 * @generated
 **/
public class RoleTest {
	
}
