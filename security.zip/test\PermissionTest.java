package security.test;

/**
 * Classe utilitária de teste Permission
 * @generated
 **/
public class PermissionTest {
	
}
