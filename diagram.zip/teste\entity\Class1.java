package diagram.teste.entity;

import java.io.*;
import javax.persistence.*;
import java.util.*;
import javax.xml.bind.annotation.*;


/**
 * Classe que representa a tabela CLASS1
 * @generated
 */
@Entity
@Table(name = "\"CLASS1\""


)
@XmlRootElement
public class Class1 implements Serializable {

	/**
	 * UID da classe, necessário na serialização 
	 * @generated
	 */
	private static final long serialVersionUID = 2020899232l;
	
	/**
	 * @generated
	 */
	@Id
    
	@Column(name = "id", insertable=true, updatable=true)
	private java.lang.String id = UUID.randomUUID().toString().toUpperCase();
	
	/**
	 * @generated
	 */
	@Column(name = "cpf", nullable = false, unique = false, insertable=true, updatable=true)
	private java.lang.String cpf;
	
	/**
	 * @generated
	 */
	@Column(name = "name", nullable = false, unique = false, insertable=true, updatable=true)
	private java.lang.String name;
	
	
	/**
	 * Construtor
	 * @generated
	 */
	public Class1(){
	}

	
	/**
	 * Obtém id
	 * @param id id
	 * return id
	 * @generated
	 */
	public java.lang.String getId(){
		return this.id;
	}
	
	/**
	 * Define id
	 * @param id id
	 * @generated
	 */
	public Class1 setId(java.lang.String id){
		this.id = id;
		return this;
	}
	
	/**
	 * Obtém cpf
	 * @param cpf cpf
	 * return cpf
	 * @generated
	 */
	public java.lang.String getCpf(){
		return this.cpf;
	}
	
	/**
	 * Define cpf
	 * @param cpf cpf
	 * @generated
	 */
	public Class1 setCpf(java.lang.String cpf){
		this.cpf = cpf;
		return this;
	}
	
	/**
	 * Obtém name
	 * @param name name
	 * return name
	 * @generated
	 */
	public java.lang.String getName(){
		return this.name;
	}
	
	/**
	 * Define name
	 * @param name name
	 * @generated
	 */
	public Class1 setName(java.lang.String name){
		this.name = name;
		return this;
	}
	
	/**
	 * @generated
	 */
	@Override
	public int hashCode() {
        final int prime = 31;
        int result = 1;

        result = prime * result + ((id == null) ? 0 : id.hashCode());

        return result;
    }
	
	/**
	 * @generated
	 */	
	@Override
  	public boolean equals(Object obj) {
    
	    if(this == obj)
	      return true;
	    
	    if(obj == null)
	      return false;
	    
	    if(!(obj instanceof Class1))
	      return false;
	    
	    Class1 other = (Class1)obj;
	    
		if(this.id == null && other.id != null)
	    	return false;
	    else if(!this.id.equals(other.id))
	     	return false;
	

	    return true;
	    
	}
}
