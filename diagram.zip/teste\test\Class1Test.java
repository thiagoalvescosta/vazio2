package diagram.teste.test;

/**
 * Classe utilitária de teste Class1
 * @generated
 **/
public class Class1Test {
	
}
